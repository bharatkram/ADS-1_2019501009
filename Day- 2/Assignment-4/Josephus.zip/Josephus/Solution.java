class Solution{
	public static String Josephus(int a, int b){
		// fill you code Here
		return "";
	}
}