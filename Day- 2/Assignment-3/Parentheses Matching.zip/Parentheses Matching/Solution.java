class Solution{
	public static String isMatching(String str){
		// fill you code Here
		return "YES";
	}
}