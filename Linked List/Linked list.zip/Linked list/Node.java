/**
 * Class for node.
 */
class Node {
	//Todo
}