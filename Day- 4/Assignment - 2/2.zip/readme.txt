Merge Sort:

Given an String array sort the array using Merge Sort

You were given a Solution file contains a method mergeSort which accepts an String array as parameter.

mergeSort – Sort the array passed as parameter by using merge sort and return the array.
