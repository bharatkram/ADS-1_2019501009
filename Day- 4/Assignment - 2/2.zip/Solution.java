class Solution{
	public static String[] mergeSort(String[] arr){
		// fill you code Here
		return arr;
	}
	
}