class Solution{
	public static int[] quickSort(int[] arr){
		// fill you code Here
		return arr;
	}
	
}