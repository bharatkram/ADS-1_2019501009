Quick Sort:

Given an Integer array sort the array using Quick Sort

You were given a Solution file contains a method quickSort which accepts an integer array as parameter.

quickSort – Sort the array passed as parameter by using quick sort and return the array.
